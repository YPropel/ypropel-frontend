--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Postgres.app)
-- Dumped by pg_dump version 17.5 (Postgres.app)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ypropel_db;
--
-- Name: ypropel_db; Type: DATABASE; Schema: -; Owner: raniaomar
--

CREATE DATABASE ypropel_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = icu LOCALE = 'en_US.UTF-8' ICU_LOCALE = 'en-US';


ALTER DATABASE ypropel_db OWNER TO raniaomar;

\connect ypropel_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.articles (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    author_id integer,
    content text NOT NULL,
    cover_image character varying(255),
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.articles OWNER TO raniaomar;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.articles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO raniaomar;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: career_path_steps; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.career_path_steps (
    id integer NOT NULL,
    career_path_id integer,
    step_number integer NOT NULL,
    description text,
    image_url character varying(500)
);


ALTER TABLE public.career_path_steps OWNER TO raniaomar;

--
-- Name: career_path_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.career_path_steps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.career_path_steps_id_seq OWNER TO raniaomar;

--
-- Name: career_path_steps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.career_path_steps_id_seq OWNED BY public.career_path_steps.id;


--
-- Name: career_paths; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.career_paths (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    image_url character varying(500),
    field character varying(255)
);


ALTER TABLE public.career_paths OWNER TO raniaomar;

--
-- Name: career_paths_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.career_paths_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.career_paths_id_seq OWNER TO raniaomar;

--
-- Name: career_paths_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.career_paths_id_seq OWNED BY public.career_paths.id;


--
-- Name: careers; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.careers (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    image_url character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.careers OWNER TO raniaomar;

--
-- Name: careers_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.careers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.careers_id_seq OWNER TO raniaomar;

--
-- Name: careers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.careers_id_seq OWNED BY public.careers.id;


--
-- Name: comments; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    post_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.comments OWNER TO raniaomar;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comments_id_seq OWNER TO raniaomar;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: course_enrollments; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.course_enrollments (
    id integer NOT NULL,
    user_id integer,
    course_id integer,
    enrolled_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.course_enrollments OWNER TO raniaomar;

--
-- Name: course_enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.course_enrollments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.course_enrollments_id_seq OWNER TO raniaomar;

--
-- Name: course_enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.course_enrollments_id_seq OWNED BY public.course_enrollments.id;


--
-- Name: experience_levels; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.experience_levels (
    id integer NOT NULL,
    level_name character varying(255) NOT NULL
);


ALTER TABLE public.experience_levels OWNER TO raniaomar;

--
-- Name: experience_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.experience_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.experience_levels_id_seq OWNER TO raniaomar;

--
-- Name: experience_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.experience_levels_id_seq OWNED BY public.experience_levels.id;


--
-- Name: freelance_services; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.freelance_services (
    id integer NOT NULL,
    member_id integer,
    name character varying(255) NOT NULL,
    description text,
    about text,
    email character varying(255),
    website character varying(500),
    service_type character varying(100),
    location character varying(255),
    rate character varying(50),
    gallery jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.freelance_services OWNER TO raniaomar;

--
-- Name: freelance_services_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.freelance_services_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.freelance_services_id_seq OWNER TO raniaomar;

--
-- Name: freelance_services_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.freelance_services_id_seq OWNED BY public.freelance_services.id;


--
-- Name: job_applications; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.job_applications (
    id integer NOT NULL,
    job_id integer,
    user_id integer,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    status character varying(50)
);


ALTER TABLE public.job_applications OWNER TO raniaomar;

--
-- Name: job_applications_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.job_applications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.job_applications_id_seq OWNER TO raniaomar;

--
-- Name: job_applications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.job_applications_id_seq OWNED BY public.job_applications.id;


--
-- Name: job_fairs; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.job_fairs (
    id integer NOT NULL,
    title character varying(200) NOT NULL,
    description text,
    location character varying(200),
    start_date date,
    end_date date,
    website character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.job_fairs OWNER TO raniaomar;

--
-- Name: job_fairs_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.job_fairs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.job_fairs_id_seq OWNER TO raniaomar;

--
-- Name: job_fairs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.job_fairs_id_seq OWNED BY public.job_fairs.id;


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.jobs (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    category character varying(50),
    company character varying(255),
    location character varying(255),
    requirements text,
    apply_url character varying(500),
    posted_by integer,
    posted_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.jobs OWNER TO raniaomar;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.jobs_id_seq OWNER TO raniaomar;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: licensable_careers; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.licensable_careers (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    cover_photo_url character varying(500),
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.licensable_careers OWNER TO raniaomar;

--
-- Name: licensable_careers_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.licensable_careers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.licensable_careers_id_seq OWNER TO raniaomar;

--
-- Name: licensable_careers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.licensable_careers_id_seq OWNED BY public.licensable_careers.id;


--
-- Name: majors; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.majors (
    id integer NOT NULL,
    name character varying(150) NOT NULL,
    cover_photo_url character varying(255),
    description text,
    popularity_rank integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.majors OWNER TO raniaomar;

--
-- Name: majors_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.majors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.majors_id_seq OWNER TO raniaomar;

--
-- Name: majors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.majors_id_seq OWNED BY public.majors.id;


--
-- Name: messages; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.messages (
    id integer NOT NULL,
    sender_id integer,
    receiver_id integer,
    message_text text NOT NULL,
    sent_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    read_at timestamp without time zone
);


ALTER TABLE public.messages OWNER TO raniaomar;

--
-- Name: messages_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.messages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.messages_id_seq OWNER TO raniaomar;

--
-- Name: messages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.messages_id_seq OWNED BY public.messages.id;


--
-- Name: mini_courses; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.mini_courses (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    author_id integer,
    price numeric(10,2),
    category character varying(255),
    duration character varying(50),
    content_url character varying(500)
);


ALTER TABLE public.mini_courses OWNER TO raniaomar;

--
-- Name: mini_courses_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.mini_courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mini_courses_id_seq OWNER TO raniaomar;

--
-- Name: mini_courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.mini_courses_id_seq OWNED BY public.mini_courses.id;


--
-- Name: music_majors; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.music_majors (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    cover_photo_url character varying(500),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.music_majors OWNER TO raniaomar;

--
-- Name: music_majors_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.music_majors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.music_majors_id_seq OWNER TO raniaomar;

--
-- Name: music_majors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.music_majors_id_seq OWNED BY public.music_majors.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer,
    type character varying(255),
    message text,
    read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notifications OWNER TO raniaomar;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO raniaomar;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: pitchpoint_videos; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.pitchpoint_videos (
    id integer NOT NULL,
    user_id integer,
    title character varying(255) NOT NULL,
    description text,
    video_url text NOT NULL,
    category character varying(100),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.pitchpoint_videos OWNER TO raniaomar;

--
-- Name: pitchpoint_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.pitchpoint_videos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pitchpoint_videos_id_seq OWNER TO raniaomar;

--
-- Name: pitchpoint_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.pitchpoint_videos_id_seq OWNED BY public.pitchpoint_videos.id;


--
-- Name: post_follows; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.post_follows (
    user_id integer NOT NULL,
    post_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.post_follows OWNER TO raniaomar;

--
-- Name: post_likes; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.post_likes (
    user_id integer NOT NULL,
    post_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.post_likes OWNER TO raniaomar;

--
-- Name: post_shares; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.post_shares (
    user_id integer NOT NULL,
    post_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.post_shares OWNER TO raniaomar;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    image_url character varying(500),
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    video_url text
);


ALTER TABLE public.posts OWNER TO raniaomar;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO raniaomar;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: pre_college_summer_programs; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.pre_college_summer_programs (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    cover_photo_url text,
    description text,
    program_type character varying(100),
    is_paid boolean DEFAULT false,
    price numeric(10,2),
    start_date date,
    end_date date,
    location character varying(255),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.pre_college_summer_programs OWNER TO raniaomar;

--
-- Name: pre_college_summer_programs_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.pre_college_summer_programs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pre_college_summer_programs_id_seq OWNER TO raniaomar;

--
-- Name: pre_college_summer_programs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.pre_college_summer_programs_id_seq OWNED BY public.pre_college_summer_programs.id;


--
-- Name: trade_schools; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.trade_schools (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    cover_photo_url character varying(500),
    website character varying(500),
    description text,
    country character varying(100),
    city character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.trade_schools OWNER TO raniaomar;

--
-- Name: trade_schools_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.trade_schools_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trade_schools_id_seq OWNER TO raniaomar;

--
-- Name: trade_schools_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.trade_schools_id_seq OWNED BY public.trade_schools.id;


--
-- Name: universities; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.universities (
    id integer NOT NULL,
    title character varying(150) NOT NULL,
    cover_photo_url character varying(255),
    website character varying(255),
    description text,
    country character varying(100),
    city character varying(100),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.universities OWNER TO raniaomar;

--
-- Name: universities_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.universities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.universities_id_seq OWNER TO raniaomar;

--
-- Name: universities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.universities_id_seq OWNED BY public.universities.id;


--
-- Name: user_connections; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.user_connections (
    follower_id integer NOT NULL,
    followee_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_connections OWNER TO raniaomar;

--
-- Name: users; Type: TABLE; Schema: public; Owner: raniaomar
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    password_hash character varying(255) NOT NULL,
    title character varying(100),
    university character varying(150),
    major character varying(150),
    experience_level character varying(100),
    skills text,
    company character varying(150),
    courses_completed text,
    country character varying(100),
    birthdate date,
    volunteering_work text,
    projects_completed text,
    photo_url character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO raniaomar;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: raniaomar
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO raniaomar;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: raniaomar
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: career_path_steps id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.career_path_steps ALTER COLUMN id SET DEFAULT nextval('public.career_path_steps_id_seq'::regclass);


--
-- Name: career_paths id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.career_paths ALTER COLUMN id SET DEFAULT nextval('public.career_paths_id_seq'::regclass);


--
-- Name: careers id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.careers ALTER COLUMN id SET DEFAULT nextval('public.careers_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: course_enrollments id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.course_enrollments ALTER COLUMN id SET DEFAULT nextval('public.course_enrollments_id_seq'::regclass);


--
-- Name: experience_levels id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.experience_levels ALTER COLUMN id SET DEFAULT nextval('public.experience_levels_id_seq'::regclass);


--
-- Name: freelance_services id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.freelance_services ALTER COLUMN id SET DEFAULT nextval('public.freelance_services_id_seq'::regclass);


--
-- Name: job_applications id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.job_applications ALTER COLUMN id SET DEFAULT nextval('public.job_applications_id_seq'::regclass);


--
-- Name: job_fairs id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.job_fairs ALTER COLUMN id SET DEFAULT nextval('public.job_fairs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: licensable_careers id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.licensable_careers ALTER COLUMN id SET DEFAULT nextval('public.licensable_careers_id_seq'::regclass);


--
-- Name: majors id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.majors ALTER COLUMN id SET DEFAULT nextval('public.majors_id_seq'::regclass);


--
-- Name: messages id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.messages ALTER COLUMN id SET DEFAULT nextval('public.messages_id_seq'::regclass);


--
-- Name: mini_courses id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.mini_courses ALTER COLUMN id SET DEFAULT nextval('public.mini_courses_id_seq'::regclass);


--
-- Name: music_majors id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.music_majors ALTER COLUMN id SET DEFAULT nextval('public.music_majors_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: pitchpoint_videos id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.pitchpoint_videos ALTER COLUMN id SET DEFAULT nextval('public.pitchpoint_videos_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: pre_college_summer_programs id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.pre_college_summer_programs ALTER COLUMN id SET DEFAULT nextval('public.pre_college_summer_programs_id_seq'::regclass);


--
-- Name: trade_schools id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.trade_schools ALTER COLUMN id SET DEFAULT nextval('public.trade_schools_id_seq'::regclass);


--
-- Name: universities id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.universities ALTER COLUMN id SET DEFAULT nextval('public.universities_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.articles (id, title, author_id, content, cover_image, published_at, created_at, updated_at) FROM stdin;
\.
COPY public.articles (id, title, author_id, content, cover_image, published_at, created_at, updated_at) FROM '$$PATH$$/3954.dat';

--
-- Data for Name: career_path_steps; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.career_path_steps (id, career_path_id, step_number, description, image_url) FROM stdin;
\.
COPY public.career_path_steps (id, career_path_id, step_number, description, image_url) FROM '$$PATH$$/3960.dat';

--
-- Data for Name: career_paths; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.career_paths (id, title, description, image_url, field) FROM stdin;
\.
COPY public.career_paths (id, title, description, image_url, field) FROM '$$PATH$$/3958.dat';

--
-- Data for Name: careers; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.careers (id, title, description, image_url, created_at, updated_at) FROM stdin;
\.
COPY public.careers (id, title, description, image_url, created_at, updated_at) FROM '$$PATH$$/3940.dat';

--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.comments (id, post_id, user_id, content, created_at, updated_at) FROM stdin;
\.
COPY public.comments (id, post_id, user_id, content, created_at, updated_at) FROM '$$PATH$$/3982.dat';

--
-- Data for Name: course_enrollments; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.course_enrollments (id, user_id, course_id, enrolled_at, completed_at) FROM stdin;
\.
COPY public.course_enrollments (id, user_id, course_id, enrolled_at, completed_at) FROM '$$PATH$$/3968.dat';

--
-- Data for Name: experience_levels; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.experience_levels (id, level_name) FROM stdin;
\.
COPY public.experience_levels (id, level_name) FROM '$$PATH$$/3956.dat';

--
-- Data for Name: freelance_services; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.freelance_services (id, member_id, name, description, about, email, website, service_type, location, rate, gallery, created_at, updated_at) FROM stdin;
\.
COPY public.freelance_services (id, member_id, name, description, about, email, website, service_type, location, rate, gallery, created_at, updated_at) FROM '$$PATH$$/3948.dat';

--
-- Data for Name: job_applications; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.job_applications (id, job_id, user_id, applied_at, status) FROM stdin;
\.
COPY public.job_applications (id, job_id, user_id, applied_at, status) FROM '$$PATH$$/3964.dat';

--
-- Data for Name: job_fairs; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.job_fairs (id, title, description, location, start_date, end_date, website, created_at, updated_at) FROM stdin;
\.
COPY public.job_fairs (id, title, description, location, start_date, end_date, website, created_at, updated_at) FROM '$$PATH$$/3952.dat';

--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.jobs (id, title, description, category, company, location, requirements, apply_url, posted_by, posted_at) FROM stdin;
\.
COPY public.jobs (id, title, description, category, company, location, requirements, apply_url, posted_by, posted_at) FROM '$$PATH$$/3962.dat';

--
-- Data for Name: licensable_careers; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.licensable_careers (id, title, cover_photo_url, description, created_at, updated_at) FROM stdin;
\.
COPY public.licensable_careers (id, title, cover_photo_url, description, created_at, updated_at) FROM '$$PATH$$/3946.dat';

--
-- Data for Name: majors; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.majors (id, name, cover_photo_url, description, popularity_rank, created_at, updated_at) FROM stdin;
\.
COPY public.majors (id, name, cover_photo_url, description, popularity_rank, created_at, updated_at) FROM '$$PATH$$/3938.dat';

--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.messages (id, sender_id, receiver_id, message_text, sent_at, read_at) FROM stdin;
\.
COPY public.messages (id, sender_id, receiver_id, message_text, sent_at, read_at) FROM '$$PATH$$/3970.dat';

--
-- Data for Name: mini_courses; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.mini_courses (id, title, description, author_id, price, category, duration, content_url) FROM stdin;
\.
COPY public.mini_courses (id, title, description, author_id, price, category, duration, content_url) FROM '$$PATH$$/3966.dat';

--
-- Data for Name: music_majors; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.music_majors (id, title, description, cover_photo_url, created_at, updated_at) FROM stdin;
\.
COPY public.music_majors (id, title, description, cover_photo_url, created_at, updated_at) FROM '$$PATH$$/3942.dat';

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.notifications (id, user_id, type, message, read, created_at) FROM stdin;
\.
COPY public.notifications (id, user_id, type, message, read, created_at) FROM '$$PATH$$/3973.dat';

--
-- Data for Name: pitchpoint_videos; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.pitchpoint_videos (id, user_id, title, description, video_url, category, created_at, updated_at) FROM stdin;
\.
COPY public.pitchpoint_videos (id, user_id, title, description, video_url, category, created_at, updated_at) FROM '$$PATH$$/3975.dat';

--
-- Data for Name: post_follows; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.post_follows (user_id, post_id, created_at) FROM stdin;
\.
COPY public.post_follows (user_id, post_id, created_at) FROM '$$PATH$$/3980.dat';

--
-- Data for Name: post_likes; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.post_likes (user_id, post_id, created_at) FROM stdin;
\.
COPY public.post_likes (user_id, post_id, created_at) FROM '$$PATH$$/3978.dat';

--
-- Data for Name: post_shares; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.post_shares (user_id, post_id, created_at) FROM stdin;
\.
COPY public.post_shares (user_id, post_id, created_at) FROM '$$PATH$$/3979.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.posts (id, user_id, title, content, image_url, created_at, updated_at, video_url) FROM stdin;
\.
COPY public.posts (id, user_id, title, content, image_url, created_at, updated_at, video_url) FROM '$$PATH$$/3977.dat';

--
-- Data for Name: pre_college_summer_programs; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.pre_college_summer_programs (id, title, cover_photo_url, description, program_type, is_paid, price, start_date, end_date, location, created_at, updated_at) FROM stdin;
\.
COPY public.pre_college_summer_programs (id, title, cover_photo_url, description, program_type, is_paid, price, start_date, end_date, location, created_at, updated_at) FROM '$$PATH$$/3950.dat';

--
-- Data for Name: trade_schools; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.trade_schools (id, title, cover_photo_url, website, description, country, city, created_at, updated_at) FROM stdin;
\.
COPY public.trade_schools (id, title, cover_photo_url, website, description, country, city, created_at, updated_at) FROM '$$PATH$$/3944.dat';

--
-- Data for Name: universities; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.universities (id, title, cover_photo_url, website, description, country, city, created_at, updated_at) FROM stdin;
\.
COPY public.universities (id, title, cover_photo_url, website, description, country, city, created_at, updated_at) FROM '$$PATH$$/3936.dat';

--
-- Data for Name: user_connections; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.user_connections (follower_id, followee_id, created_at) FROM stdin;
\.
COPY public.user_connections (follower_id, followee_id, created_at) FROM '$$PATH$$/3971.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: raniaomar
--

COPY public.users (id, name, email, password_hash, title, university, major, experience_level, skills, company, courses_completed, country, birthdate, volunteering_work, projects_completed, photo_url, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, name, email, password_hash, title, university, major, experience_level, skills, company, courses_completed, country, birthdate, volunteering_work, projects_completed, photo_url, created_at, updated_at) FROM '$$PATH$$/3934.dat';

--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.articles_id_seq', 1, false);


--
-- Name: career_path_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.career_path_steps_id_seq', 1, false);


--
-- Name: career_paths_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.career_paths_id_seq', 1, false);


--
-- Name: careers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.careers_id_seq', 1, false);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.comments_id_seq', 29, true);


--
-- Name: course_enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.course_enrollments_id_seq', 1, false);


--
-- Name: experience_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.experience_levels_id_seq', 1, false);


--
-- Name: freelance_services_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.freelance_services_id_seq', 1, false);


--
-- Name: job_applications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.job_applications_id_seq', 1, false);


--
-- Name: job_fairs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.job_fairs_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, false);


--
-- Name: licensable_careers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.licensable_careers_id_seq', 1, false);


--
-- Name: majors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.majors_id_seq', 4, true);


--
-- Name: messages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.messages_id_seq', 1, false);


--
-- Name: mini_courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.mini_courses_id_seq', 1, false);


--
-- Name: music_majors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.music_majors_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: pitchpoint_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.pitchpoint_videos_id_seq', 1, false);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.posts_id_seq', 21, true);


--
-- Name: pre_college_summer_programs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.pre_college_summer_programs_id_seq', 3, true);


--
-- Name: trade_schools_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.trade_schools_id_seq', 1, false);


--
-- Name: universities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.universities_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: raniaomar
--

SELECT pg_catalog.setval('public.users_id_seq', 10, true);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: career_path_steps career_path_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.career_path_steps
    ADD CONSTRAINT career_path_steps_pkey PRIMARY KEY (id);


--
-- Name: career_paths career_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.career_paths
    ADD CONSTRAINT career_paths_pkey PRIMARY KEY (id);


--
-- Name: careers careers_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.careers
    ADD CONSTRAINT careers_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: course_enrollments course_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_pkey PRIMARY KEY (id);


--
-- Name: experience_levels experience_levels_level_name_key; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.experience_levels
    ADD CONSTRAINT experience_levels_level_name_key UNIQUE (level_name);


--
-- Name: experience_levels experience_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.experience_levels
    ADD CONSTRAINT experience_levels_pkey PRIMARY KEY (id);


--
-- Name: freelance_services freelance_services_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.freelance_services
    ADD CONSTRAINT freelance_services_pkey PRIMARY KEY (id);


--
-- Name: job_applications job_applications_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_pkey PRIMARY KEY (id);


--
-- Name: job_fairs job_fairs_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.job_fairs
    ADD CONSTRAINT job_fairs_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: licensable_careers licensable_careers_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.licensable_careers
    ADD CONSTRAINT licensable_careers_pkey PRIMARY KEY (id);


--
-- Name: majors majors_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.majors
    ADD CONSTRAINT majors_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: mini_courses mini_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.mini_courses
    ADD CONSTRAINT mini_courses_pkey PRIMARY KEY (id);


--
-- Name: music_majors music_majors_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.music_majors
    ADD CONSTRAINT music_majors_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: pitchpoint_videos pitchpoint_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.pitchpoint_videos
    ADD CONSTRAINT pitchpoint_videos_pkey PRIMARY KEY (id);


--
-- Name: post_follows post_follows_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_follows
    ADD CONSTRAINT post_follows_pkey PRIMARY KEY (user_id, post_id);


--
-- Name: post_likes post_likes_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_pkey PRIMARY KEY (user_id, post_id);


--
-- Name: post_shares post_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_shares
    ADD CONSTRAINT post_shares_pkey PRIMARY KEY (user_id, post_id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: pre_college_summer_programs pre_college_summer_programs_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.pre_college_summer_programs
    ADD CONSTRAINT pre_college_summer_programs_pkey PRIMARY KEY (id);


--
-- Name: trade_schools trade_schools_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.trade_schools
    ADD CONSTRAINT trade_schools_pkey PRIMARY KEY (id);


--
-- Name: universities universities_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.universities
    ADD CONSTRAINT universities_pkey PRIMARY KEY (id);


--
-- Name: user_connections user_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.user_connections
    ADD CONSTRAINT user_connections_pkey PRIMARY KEY (follower_id, followee_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: articles articles_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: career_path_steps career_path_steps_career_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.career_path_steps
    ADD CONSTRAINT career_path_steps_career_path_id_fkey FOREIGN KEY (career_path_id) REFERENCES public.career_paths(id) ON DELETE CASCADE;


--
-- Name: comments comments_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: comments comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: course_enrollments course_enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.mini_courses(id) ON DELETE CASCADE;


--
-- Name: course_enrollments course_enrollments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: freelance_services freelance_services_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.freelance_services
    ADD CONSTRAINT freelance_services_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_job_id_fkey FOREIGN KEY (job_id) REFERENCES public.jobs(id) ON DELETE CASCADE;


--
-- Name: job_applications job_applications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.job_applications
    ADD CONSTRAINT job_applications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: jobs jobs_posted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_posted_by_fkey FOREIGN KEY (posted_by) REFERENCES public.users(id);


--
-- Name: messages messages_receiver_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: mini_courses mini_courses_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.mini_courses
    ADD CONSTRAINT mini_courses_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: pitchpoint_videos pitchpoint_videos_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.pitchpoint_videos
    ADD CONSTRAINT pitchpoint_videos_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: post_follows post_follows_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_follows
    ADD CONSTRAINT post_follows_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_follows post_follows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_follows
    ADD CONSTRAINT post_follows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: post_likes post_likes_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_likes post_likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_likes
    ADD CONSTRAINT post_likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: post_shares post_shares_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_shares
    ADD CONSTRAINT post_shares_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: post_shares post_shares_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.post_shares
    ADD CONSTRAINT post_shares_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_connections user_connections_followee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.user_connections
    ADD CONSTRAINT user_connections_followee_id_fkey FOREIGN KEY (followee_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_connections user_connections_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: raniaomar
--

ALTER TABLE ONLY public.user_connections
    ADD CONSTRAINT user_connections_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: DATABASE ypropel_db; Type: ACL; Schema: -; Owner: raniaomar
--

GRANT ALL ON DATABASE ypropel_db TO ypropel;


--
-- Name: TABLE articles; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.articles TO ypropel;


--
-- Name: SEQUENCE articles_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.articles_id_seq TO ypropel;


--
-- Name: TABLE career_path_steps; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.career_path_steps TO ypropel;


--
-- Name: SEQUENCE career_path_steps_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.career_path_steps_id_seq TO ypropel;


--
-- Name: TABLE career_paths; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.career_paths TO ypropel;


--
-- Name: SEQUENCE career_paths_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.career_paths_id_seq TO ypropel;


--
-- Name: TABLE careers; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.careers TO ypropel;


--
-- Name: SEQUENCE careers_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.careers_id_seq TO ypropel;


--
-- Name: TABLE comments; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.comments TO ypropel;


--
-- Name: SEQUENCE comments_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.comments_id_seq TO ypropel;


--
-- Name: TABLE course_enrollments; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.course_enrollments TO ypropel;


--
-- Name: SEQUENCE course_enrollments_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.course_enrollments_id_seq TO ypropel;


--
-- Name: TABLE experience_levels; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.experience_levels TO ypropel;


--
-- Name: SEQUENCE experience_levels_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.experience_levels_id_seq TO ypropel;


--
-- Name: TABLE freelance_services; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.freelance_services TO ypropel;


--
-- Name: SEQUENCE freelance_services_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.freelance_services_id_seq TO ypropel;


--
-- Name: TABLE job_applications; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.job_applications TO ypropel;


--
-- Name: SEQUENCE job_applications_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.job_applications_id_seq TO ypropel;


--
-- Name: TABLE job_fairs; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.job_fairs TO ypropel;


--
-- Name: SEQUENCE job_fairs_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.job_fairs_id_seq TO ypropel;


--
-- Name: TABLE jobs; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.jobs TO ypropel;


--
-- Name: SEQUENCE jobs_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.jobs_id_seq TO ypropel;


--
-- Name: TABLE licensable_careers; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.licensable_careers TO ypropel;


--
-- Name: SEQUENCE licensable_careers_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.licensable_careers_id_seq TO ypropel;


--
-- Name: TABLE majors; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.majors TO ypropel;


--
-- Name: SEQUENCE majors_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.majors_id_seq TO ypropel;


--
-- Name: TABLE messages; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.messages TO ypropel;


--
-- Name: SEQUENCE messages_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.messages_id_seq TO ypropel;


--
-- Name: TABLE mini_courses; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mini_courses TO ypropel;


--
-- Name: SEQUENCE mini_courses_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.mini_courses_id_seq TO ypropel;


--
-- Name: TABLE music_majors; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.music_majors TO ypropel;


--
-- Name: SEQUENCE music_majors_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.music_majors_id_seq TO ypropel;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.notifications TO ypropel;


--
-- Name: SEQUENCE notifications_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.notifications_id_seq TO ypropel;


--
-- Name: TABLE pitchpoint_videos; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pitchpoint_videos TO ypropel;


--
-- Name: SEQUENCE pitchpoint_videos_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.pitchpoint_videos_id_seq TO ypropel;


--
-- Name: TABLE post_follows; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.post_follows TO ypropel;


--
-- Name: TABLE post_likes; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.post_likes TO ypropel;


--
-- Name: TABLE post_shares; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.post_shares TO ypropel;


--
-- Name: TABLE posts; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.posts TO ypropel;


--
-- Name: SEQUENCE posts_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.posts_id_seq TO ypropel;


--
-- Name: TABLE pre_college_summer_programs; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.pre_college_summer_programs TO ypropel;


--
-- Name: SEQUENCE pre_college_summer_programs_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.pre_college_summer_programs_id_seq TO ypropel;


--
-- Name: TABLE trade_schools; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.trade_schools TO ypropel;


--
-- Name: SEQUENCE trade_schools_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.trade_schools_id_seq TO ypropel;


--
-- Name: TABLE universities; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.universities TO ypropel;


--
-- Name: SEQUENCE universities_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.universities_id_seq TO ypropel;


--
-- Name: TABLE user_connections; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.user_connections TO ypropel;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO ypropel;


--
-- Name: SEQUENCE users_id_seq; Type: ACL; Schema: public; Owner: raniaomar
--

GRANT SELECT,USAGE ON SEQUENCE public.users_id_seq TO ypropel;


--
-- PostgreSQL database dump complete
--

